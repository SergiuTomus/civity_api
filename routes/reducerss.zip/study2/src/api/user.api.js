import axios from '../config/axios';
import { call } from 'redux-saga/effects';
import {USER_REGISTER_ENDPOINT} from '../config/endpoints';

export function* register(payload){

    return yield call(axios.post, USER_REGISTER_ENDPOINT, payload);

}
