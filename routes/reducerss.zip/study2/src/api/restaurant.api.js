import axios from '../config/axios';
import { call } from 'redux-saga/effects';
import {GET_RESTAURANT_ENDPOINT} from '../config/endpoints';

export function* register(payload){

    return yield call(axios.get, GET_RESTAURANT_ENDPOINT, payload);

}
