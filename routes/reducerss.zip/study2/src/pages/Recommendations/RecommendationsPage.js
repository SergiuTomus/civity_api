import React, { Component } from 'react';
import { connect } from 'react-redux';

class RecommendationsPage extends Component {

  render() {
      return (
        <div>
          RecommandationsPage
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(RecommendationsPage);