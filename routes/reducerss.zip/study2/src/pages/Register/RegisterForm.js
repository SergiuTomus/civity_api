import React from 'react';
import {Field, reduxForm} from 'redux-form';

//Validation
const validate = values => {
    const errors = {};

    if(!values.email){
        errors.email = 'Required';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
        errors.email = 'Invalid email address';
    }

    if(!values.password){
        errors.password = 'Required';
    }else if(!/^(?=.{8,})$/i.test(values.password)){
        // errors.password = "Password string must contain at least 1 uppercase, one numeric, one special character, with a length of at least 8 characters";
    }

    if(!values.password_confirmation){
        errors.password_confirmation = 'Required';
    }else if(values.password_confirmation !== values.password){
        errors.password_confirmation = 'Confirmation password does not match password';
    }

    return errors;
}

const renderField = ({ input, label, type, meta: { touched, error, warning } }) => (
    <div>
      <label className="control-label">{label}</label>
      <div>
        <input {...input} placeholder={label} type={type} className="form-control" />
        {touched && ((error && <span className="text-danger">{error}</span>) || (warning && <span>{warning}</span>))}
      </div>
    </div>
  )


let RegisterForm = props => {
    const {handleSubmit} = props
    return (
        <form onSubmit={handleSubmit}>

            <div>
                <label>Email</label>
                <Field name="email" component={renderField} type="email" />
            </div>

            <div>
                <label>Password</label>
                <Field name="password" component={renderField} type="password" />
            </div>

            <div>
                <label>Password confirmation</label>
                <Field name="password_confirmation" component={renderField} type="password" />
            </div>

            <div>
                <button type="submit">Submit</button>
            </div>
           
        </form>
    )
}

RegisterForm = reduxForm({
    form: 'register',
    validate
})(RegisterForm)

export default RegisterForm;