import React, { Component } from 'react';
import RegisterForm from './RegisterForm';
import { connect } from 'react-redux';
import {requestRegisterAction} from '../../actions/user.actions';

import Spinner from '../../components/spinner/spinner.component';

class RegisterPage extends Component {
    
    constructor(props){
        super(props);
    }

    handleSubmit(values){
        this.props.requestRegisterAction(values);
    }
    
    render(){
        return (
            <div>
                {this.props.loading !== 0 ? <Spinner /> : ''}
                {this.props.success}
                {this.props.error}
                <RegisterForm onSubmit={this.handleSubmit.bind(this)} />
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        // error : 'test',
        loading: state.loadingReducer.pendingRequests,
        error : state.userReducer.registerErrorMessage,
        success: state.userReducer.registerSuccessMessage
    }
}

const mapDispatchToProps = {
    requestRegisterAction
}

export default connect(mapStateToProps, mapDispatchToProps)(RegisterPage)