import React, { Component } from 'react';
import { connect } from 'react-redux';

class RestaurantsPage extends Component {

  render() {
      return (
        <div>
          RestaurantsPage
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(RestaurantsPage);