import React, { Component } from 'react';
import { connect } from 'react-redux';

class CategoriesPage extends Component {

  render() {
      return (
        <div>
           CategoriesPage
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(CategoriesPage);