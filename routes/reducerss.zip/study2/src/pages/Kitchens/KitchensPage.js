import React, { Component } from 'react';
import { connect } from 'react-redux';

class KitchensPage extends Component {

  render() {
      return (
        <div>
          KitchensPage
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(KitchensPage);