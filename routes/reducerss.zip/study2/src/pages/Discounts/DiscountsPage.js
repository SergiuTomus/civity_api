import React, { Component } from 'react';
import { connect } from 'react-redux';

class DiscountsPage extends Component {

  render() {
      return (
        <div>
          DiscountsPage
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(DiscountsPage);