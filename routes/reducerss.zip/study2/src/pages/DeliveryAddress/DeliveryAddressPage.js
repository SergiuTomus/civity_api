import React, { Component } from 'react';
import { connect } from 'react-redux';

class DeliveryAddressPage extends Component {

  render() {
      return (
        <div>
          DeliveryAddressPage
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(DeliveryAddressPage);