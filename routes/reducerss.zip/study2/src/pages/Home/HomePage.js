// @flow
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';

type HomeProps = {
  prop: string,
};

type HomeState = {
  state: string,
};

class HomePage extends Component<HomeProps, HomeState>{

  render() {
      return (
        <div>
          <FormattedMessage id="homepage" defaultMessage="My default message"/>
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(HomePage);