import React, { Component } from 'react';
import { connect } from 'react-redux';

class OrderHistoryPage extends Component {

  render() {
      return (
        <div>
          OrderHistoryPage
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(OrderHistoryPage);