import React, { Component } from 'react';
import { connect } from 'react-redux';

class ShoppingCartPage extends Component {

  render() {
      return (
        <div>
          ShoppingCartPage
        </div>
      );
  }

}

const mapStateToProps = state => ({
  //
});
export default connect(mapStateToProps, {})(ShoppingCartPage);