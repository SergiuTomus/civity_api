import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';

// THIS COMPONENT IS USED WITH REDUX AND WITHOUT REDUX
// WHEN IS USED WITH REDUX PROPS RECEIVED WILL BE LOADING
// WHEN IS USED WITHOUT REDUX PROPS RECEIVED WILL BE IS_LOADING

class Spinner extends Component {
    render() {
        return (
            <Fragment>
                {this.props.loading !== 0 || this.props.isLoading ?
                    <div>
                        <div className="loader"></div>
                    </div> : ""
                }
            </Fragment>
        );
    }
}

const mapStateToProps = state => ({
    loading: state.loadingReducer.pendingRequests
});
export default connect(mapStateToProps, {})(Spinner);
