//@flow
import React, { Component } from 'react';
import { Field, reduxForm } from 'redux-form';
import { FormattedMessage, defineMessages, intlShape, injectIntl } from 'react-intl';
import BootstrapInput from '../Form/BootstrapInput';
import { required } from '../../common/validations/required';
import { email } from '../../common/validations/email';

const EXTRA_TRANSLATIONS = defineMessages({
    placeholderEmail: {
        id: 'loginForm.email',
        defaultMessage: 'Your Email',
    },
    placeholderPassword: {
        id: 'loginForm.password',
        defaultMessage: 'Password',
    },
});
export type TLoginFormProps = {
    intl: intlShape,
    onSubmit: Function,
}

class LoginForm extends Component<TLoginFormProps> {
    render () {
        const {handleSubmit, intl} = this.props;
        return (
			<div className="login">
				<div className="row">
					<div className="col-12">
						<div className="loginFormContainer">
							<form onSubmit={handleSubmit}>
								<div className="form-row">
									<Field
										name="email"
										placeholder={intl.formatMessage(EXTRA_TRANSLATIONS.placeholderEmail)}
										type="email"
										component={BootstrapInput}
										validate={[required, email]}
									/>
								</div>
								<div className="form-row">
									<Field
										name="password"
										placeholder={intl.formatMessage(EXTRA_TRANSLATIONS.placeholderPassword)}
										type="password"
										component={BootstrapInput}
										validate={[required]}
									/>
								</div>
								<div className="form-row">
									<button type="submit" className="btn btn-lg btn-green">
										<FormattedMessage id="loginForm.login" defaultMessage="LOG IN"/>
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
        );
    }
}

export default injectIntl(reduxForm({
    form: 'login'
})(LoginForm));
