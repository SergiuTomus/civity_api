import {call, takeLatest} from 'redux-saga/effects';
import { REQUEST_REGISTER } from '../actions/actions';
import { register } from '../api/user.api';
import baseRequest from './helper.saga.js'


function* registerUser(action){
    
    //Do something with response data that can't be done in a reducer
    let response = yield call(baseRequest, action, register);
}

export default function* userSaga(){
    yield takeLatest(REQUEST_REGISTER, registerUser);
}