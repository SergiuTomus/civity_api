import axios from 'axios';
import KJUR from "jsrsasign";

axios.defaults.baseURL = process.env.REACT_APP_API_BASE_URL;
axios.defaults.headers.common['Content-Type'] = 'application/json';
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
axios.defaults.headers.common['Accept'] = 'application/json';
axios.interceptors.request.use(request => {
    
    let payload = request.data ? request.data : []; 

    let token = KJUR.jws.JWS.sign(
        null,
        { typ: "JWT", alg: "HS256" },
        payload,
        process.env.REACT_APP_API_KEY
    );
    
    request.data = {
        token : token

    }

    return request;
});

export default axios;