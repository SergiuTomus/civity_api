//############################################ USER-ENDPOINTS ###############################
export const USER_REGISTER_ENDPOINT = '/api_v2/v2/customers/register';

//############################################ RESTAURANT-ENDPOINTS ###############################
export const GET_RESTAURANT_ENDPOINT = '';