import {
    REQUEST_REGISTER
} from './actions';

export const requestRegisterAction = (payload) => ({
    type: REQUEST_REGISTER,
    payload: payload
});