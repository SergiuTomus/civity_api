
import {SHOW_GENERAL_ERROR, REQUEST_SUCCEEDED, REQUEST_FAILED, HIDE_GENERAL_ERROR} from './actions';

export const showGeneralError = (payload) => ({
    type : SHOW_GENERAL_ERROR,
    payload
})

export const hideGeneralError = (payload) => ({
    type : HIDE_GENERAL_ERROR,
    payload
})

export const requestSucceeded = (actionType, payload) => ({
    type: REQUEST_SUCCEEDED,
    payload: { "type": actionType, "response" : payload}
});

export const requestFailed = (actionType, payload) => ({
    type: REQUEST_FAILED,
    payload: { "type": actionType, "response" : payload}
});

