import ro_messages from '../lang/ro.json';
import en_messages from '../lang/en.json';
import hu_messages from '../lang/hu.json';

export default {
    'ro': ro_messages,
    'en': en_messages,
    'hu': hu_messages
};