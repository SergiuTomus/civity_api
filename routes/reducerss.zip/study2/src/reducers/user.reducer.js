import {REQUEST_SUCCEEDED, REQUEST_REGISTER, REQUEST_FAILED} from '../actions/actions';



const userReducer = (state = {}, action) => {
    
    switch (action.type) {
        case REQUEST_SUCCEEDED:
            switch(action.payload.type){

                case REQUEST_REGISTER:
                    //Here we have access to response data
                    let successMessage = action.payload.response.data.message ? action.payload.response.data.message : 'User created succsessfully';
                    return {
                        ...state,
                        registerSuccessMessage: successMessage,
                        registerErrorMessage: null
                    }
            }
        
        case REQUEST_FAILED:
            switch(action.payload.type){
                case REQUEST_REGISTER:
                    //Here we have access to response data 
                    let errorMessage = action.payload.response.data.message ? action.payload.response.data.message : null;
                    return {
                        ...state,
                        registerErrorMessage: errorMessage,
                        registerSuccessMessage: null
                    };
            }
        default:
            return state;
    }

    
}

export default userReducer;