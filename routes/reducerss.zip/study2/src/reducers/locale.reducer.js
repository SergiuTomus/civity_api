// @flow
type State = {
  lang: string
}

type Action = {
  type: string
}

const initialState: State = {
    lang: "ro"
};

export default function (state: State = initialState, action: Action) {
    switch (action.type) {
        default:
            return state;
    }
}