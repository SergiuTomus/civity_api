import { INCREMENT_PENDING_REQUESTS, DECREMENT_PENDING_REQUESTS } from "../actions/actions";

const initalState = {
    pendingRequests: 0
}

const loadingReducer = (state = initalState, action) => {
    
    switch (action.type) {
        case INCREMENT_PENDING_REQUESTS:
            return {
                ...state,
                pendingRequests: state.pendingRequests + 1
            }
        case DECREMENT_PENDING_REQUESTS:
            return {
                ...state,
                pendingRequests: state.pendingRequests - 1
            }
        default:
            return state
    }
}
export default loadingReducer;
