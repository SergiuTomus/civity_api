import { SHOW_GENERAL_ERROR, HIDE_GENERAL_ERROR } from '../actions/actions';

export default function (state = {}, action) {
    switch (action.type) {
        case SHOW_GENERAL_ERROR:
            return {
                ...state,
                errorMessage: action.payload
            }
        case HIDE_GENERAL_ERROR:
            return {
                ...state,
                errorMessage: action.payload
            }
        default:
            return state;
    }
}
