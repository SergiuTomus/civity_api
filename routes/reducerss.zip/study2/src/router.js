// @flow
import React, { Component } from 'react';
import { Route, withRouter, Switch } from 'react-router';
import { addLocaleData, IntlProvider } from "react-intl";
import { connect } from "react-redux";
import {GeneralError} from './components/error/generalError.component';
import {
  HOME_ROUTE,
  KITCHENS_ROUTE,
  RESTAURANTS_ROUTE,
  CATEGORIES_ROUTE,
  REGISTER_ROUTE,
  RECOMMENDATIONS_ROUTE,
  DELIVERY_ADDRESS_ROUTE,
  DISCOUNTS_ROUTE,
  SHOPPING_CART_ROUTE,
  ORDER_HISTORY_ROUTE
} from "./config/routes";
import Home from "./pages/Home/HomePage";
import Register from './pages/Register/RegisterPage';
import KitchensPage from "./pages/Kitchens/KitchensPage";
import RestaurantsPage from "./pages/Restaurants/RestaurantsPage";
import CategoriesPage from "./pages/Categories/CategoriesPage";
import RecommendationsPage from "./pages/Recommendations/RecommendationsPage";
import DeliveryAddressPage from "./pages/DeliveryAddress/DeliveryAddressPage";
import DiscountsPage from "./pages/Discounts/DiscountsPage";
import ShoppingCartPage from "./pages/ShoppingCart/ShoppingCartPage";
import OrderHistoryPage from "./pages/OrderHistory/OrderHistoryPage";
import messages from './translations/messages/messages';
// $FlowFixMe
import ro from 'react-intl/locale-data/ro';
// $FlowFixMe
import en from 'react-intl/locale-data/en';
// $FlowFixMe
import hu from 'react-intl/locale-data/hu';

type generalError = {
  errorMessage: string
}

type Props = {
  lang: string,
  generalError: generalError
};

type State = {
  state: string
};


class Router extends Component<Props, State> {
    
  componentWillMount() {
      addLocaleData([...ro, ...en, ...hu]);
  }

  render() {
      const lang: string= this.props.lang;
      return (
        <IntlProvider locale={lang} messages={messages[lang]}>
          <div className="front">
              {this.props.generalError.errorMessage && <GeneralError error={this.props.generalError.errorMessage} />}
              <div className="content">
                  <Switch>
                      <Route path={REGISTER_ROUTE} exact component={Register} />
                      <Route path={HOME_ROUTE} exact component={Home} />
                      <Route path={KITCHENS_ROUTE} exact component={KitchensPage} />
                      <Route path={RESTAURANTS_ROUTE} exact component={RestaurantsPage} />
                      <Route path={CATEGORIES_ROUTE} exact component={CategoriesPage} />
                      <Route path={RECOMMENDATIONS_ROUTE} exact component={RecommendationsPage} />
                      <Route path={DELIVERY_ADDRESS_ROUTE} exact component={DeliveryAddressPage} />
                      <Route path={DISCOUNTS_ROUTE} exact component={DiscountsPage} />
                      <Route path={SHOPPING_CART_ROUTE} exact component={ShoppingCartPage} />
                      <Route path={ORDER_HISTORY_ROUTE} exact component={OrderHistoryPage} />
                  </Switch>
              </div>
          </div>
        </IntlProvider>
      );
  }
}

const mapStateToProps = state => ({
  generalError: state.generalReducer,
  lang: state.locale.lang
});

// $FlowFixMe
export default withRouter(connect(mapStateToProps, {})(Router));