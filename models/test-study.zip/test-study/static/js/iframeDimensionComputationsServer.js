 // Get height of document
function getDocHeight(doc) {
    doc = doc || document;
    var body = doc.body, html = doc.documentElement;
    var height = Math.max( body.scrollHeight, body.offsetHeight,
        html.clientHeight, html.scrollHeight, html.offsetHeight );
    return height;
}

// Get width of document
function getDocWidth(doc) {
    doc = doc || document;
    var body = doc.body, html = doc.documentElement;
    var width = Math.max( body.scrollWidth, body.offsetWidth,
        html.clientWidth, html.scrollWidth, html.offsetWidth );
    return width;
}

// send docHeight onload
function sendDocDimensionsMsg(e) {
    var ht = getDocHeight();
    var wt = getDocWidth();
    parent.postMessage( JSON.stringify( {'docHeight': ht, 'docWidth': wt} ), '*' );
}

  // send docHeight onload
function resetDocDimensionsMsg(e) {
    parent.postMessage( JSON.stringify( {'reset':true} ), '*' );
}

function showHideChat() {
    var chatContainer = $('.chat-bot-container');
    if (chatContainer.css("display") === "none") {
        chatContainer.css("display", "block");
        $(".open-close").attr("src", chatCloseImg);
        sendDocDimensionsMsg();
    } else {
        resetDocDimensionsMsg()
        chatContainer.css("display", "none");
        $(".open-close").attr("src", chatOpenImg);
    }
}