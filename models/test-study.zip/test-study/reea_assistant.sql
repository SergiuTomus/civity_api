-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2019 at 11:48 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reea_assistant`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `dialogflow_project_id` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `credentials` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `name`, `token`, `dialogflow_project_id`, `domain`, `credentials`) VALUES
(1, 'Reea Chatbot', '1a8d3cf9cde4b7a6728ee698b435b5ca', 'reeassistant', 'chatbot.localhost', '{\r\n  \"type\": \"service_account\",\r\n  \"project_id\": \"reeassistant\",\r\n  \"private_key_id\": \"05e327d747030655bce8fb5697e185e6771318d7\",\r\n  \"private_key\": \"-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCZcNcYgSs9Llx/\\n0rCUpYmBr8jtq1TlDvEgtdi4aFhzAB0znV9/kppElItaeGO4b1t7EYx3g7PBnjHY\\nzBDe2T+plR3dkiLyWH5FPoHqBFg5iXhVsWhDl9lrLQ1M4twciixpwuSdfuIIwNkK\\nfAptxxSCc85s5lbeLByHf3FE7L5MvOZ3wbVwK278v6YsOZP+y/erb7zArCCAVxOB\\nZfbVrGFBQqhxRfWNuJ69injmJvWTCCFwBt0pngFhniC73oQt/YW4GKc9Dlm2gS0b\\niHkKyv96ulcCsLFchLi1nbeqtN25sLbZX22aM8WT/Kp+0MyI1WIwmzJCG/XhKUwJ\\nSpl6GWFNAgMBAAECggEAQRQO5qHCSQykxsIBiso66/o2ajdEpnIT6x+1b2EyQnRF\\n7mJM4rq3G2c1Q4XUJaF1V1k2DmqZjwEdeynx7dKOocpRBGy6zbait5OvXiXBlYWs\\nuAuqgSCiYkaVYYrGeIRSGflDJVlvXO8OHthFRBIvrLSZVK7NISXsY7u1utn+TGUZ\\n5gbDDl4Jrsh9fD6+F55VVwZPntFRD+u6OYQf8r5YTQXCjnVhZDUq4+XYfli1orSx\\nU3sTr1zknESFM53hTkuv9RYSMQpayMQFwUD6mULV0fK4XQKAN3NqFDZOUN9PedSp\\nk7v+8QJq/s8nzWdSQp7bkS+kIA9sNcTjIwwlI0dOMQKBgQDJaUNhi6onHCUuJaj+\\nlDBIiX7b0GPUtE/HKxXFE1i291XG424cAmbESl6XDcAIvTbNQ9D9D5SGOnrsaKGv\\n76FR5UZwXkZ94wEe2eFCmpbY2tKoS4wzcLwL/guRoAwAxmAIb6aBy23qZ5gjsaaZ\\n7ibAaRhppUTKnYY6L9HAQjLkPwKBgQDDBzFu2VUb/lmXaAp3E1Sl6P1hPcjnsRdg\\nn9xbQExE6U/yf5Yz3GFx431B/toMvnCWTHEMQAzoTHIjfPLiDpHbeXdDcNh5nokY\\nVry6fQwwKK+zlKvBpslJb+nzlCGCpUASbfHG9WfEZSSfS3W48PNkSxK927GEJdLO\\nSS1TPLjncwKBgQDHbpiOtRmlokPafuXoNtncaXEYvS6sxmIcZ7glrTNx8FSaHEbC\\nK0qQ4MbqsW3N+XWTKKx+d3fstWlUP4KiUBgfnHPz/hW0vxsz7jAToDjvvzVJ+Yx4\\nvw8knMfdyWk5NzSOBegMq19J9Iv8BANgdiUe7rGComgMbJAle4Yo5iO4RwKBgHH+\\n61sSt9fEBVQloTBW4TyVAj3rolojPjnhVykTXUFOaseg4gfwQhkS0q1XrNaUHjUL\\n+2wgqCrEPFcX+tQ9le4Ggrqt5Cq6iwHp+Si8XPptXb4HIZnwxmkhfEs/A5NcyiW7\\nk/4qhXvbbtuZfPccB/hQlWTaXFmUzjJ7vX2Q2beXAoGBAIZKPe6OEl7n5Oa2/faE\\nW8atbnibguVDBUNG453HuIx+i7mQQTVIT46lP2/q/SW2G79QfIZ7zMWzQpUmUq7e\\nwuMR4IooLFoNLDkQzr9uBBv7B+p1/+gNR+OAeLmHxvBKe3wsP2aZWjPZ7xMhKUfu\\nlS9SqcjN9mB/DI2tZCRCuU++\\n-----END PRIVATE KEY-----\\n\",\r\n  \"client_email\": \"dialogflow-nuoxqp@reeassistant.iam.gserviceaccount.com\",\r\n  \"client_id\": \"118291803452684403317\",\r\n  \"auth_uri\": \"https://accounts.google.com/o/oauth2/auth\",\r\n  \"token_uri\": \"https://oauth2.googleapis.com/token\",\r\n  \"auth_provider_x509_cert_url\": \"https://www.googleapis.com/oauth2/v1/certs\",\r\n  \"client_x509_cert_url\": \"https://www.googleapis.com/robot/v1/metadata/x509/dialogflow-nuoxqp%40reeassistant.iam.gserviceaccount.com\"\r\n}');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
