import os
import requests
import json
import random
from flask import jsonify
from responses import responses


def call_action(data):
    # intent display name
    intent = data['queryResult']['intent']['displayName']

    switcher = {
        'contact': get_contact_details_answer,
        'description': get_company_description_answer,
        'estimations': get_estimations_answer,
        'interview': get_interview_answer,
        'portfolio': get_portfolio_answer,
        'services': get_services_answer,
        'estimations-yes': get_estimations_yes_answer,
        'estimations-no': get_estimations_no_answer,
        'technologies': get_technologies_answer
    }
    func = switcher.get(intent, lambda: "Invalid intent")
    response = func(data)

    return response


def get_company_description_answer(data):
    reply = {
        "fulfillmentText": responses['description'],
    }

    return jsonify(reply)


def get_interview_answer(data):
    reply = {
        "fulfillmentText": responses['interview'],
    }

    return jsonify(reply)


def get_portfolio_answer(data):
    reply = {
        "fulfillmentText": responses['portfolio'],
    }

    return jsonify(reply)


def get_services_answer(data):
    response = ''
    service_type = data['queryResult']['parameters'].get('serviceType')

    # if no "service type" entity is present, then just return the default answer for "services" intent
    if service_type == '':
        # when the entity is not present in the sentence, we return a general response
        response = responses['services']['general']
    else:
        # enters only when the entity exists in Dialogflow and it is present within the user input (ex: "web dev")
        response = responses['services']['target_entity'].format(service_type)

    reply = {
        "fulfillmentText": response,
    }

    return jsonify(reply)


def get_contact_details_answer(data):
    response = ''
    contact = data['queryResult']['parameters'].get('contact')

    if contact == "phone number":
        all_responses = responses['contact']['phone']
        response = random.choice(all_responses)
    elif contact == "email":
        all_responses = responses['contact']['email']
        response = random.choice(all_responses)
    else:
        response = responses['contact']['general']

    reply = {
        "fulfillmentText": response
    }

    return jsonify(reply)


def get_technologies_answer(data):
    response = ''
    tech_type = data['queryResult']['parameters'].get('techType')

    # if no "technology type" entity is present, then just return the default answer for "technologies" intent
    if tech_type == '':
        # when the entity is not present in the sentence, we return a general response
        response = responses['technologies']['general']
    else:
        # enters only when the DialogFlow entity exists in Dialogflow and it is present within the user input
        # (ex: "AngularJS, NodeJS, Pyton, PHP, etc")
        response = responses['technologies']['target_entity'].format(tech_type)

    reply = {
        "fulfillmentText": response,
    }

    return jsonify(reply)


def get_estimations_answer(data):
    reply = {
        "fulfillmentText": responses['estimations-yes'],
    }

    return jsonify(reply)


def get_estimations_yes_answer(data):
    reply = {
        "fulfillmentText": responses['estimations-yes'],
    }

    return jsonify(reply)


def get_estimations_no_answer(data):
    reply = {
        "fulfillmentText": responses['estimations-no'],
    }

    return jsonify(reply)
