responses = {
    'description'           : 'REEA is a software development and web design agency. The story started in Târgu Mureș '
                              'with a handful of enthusiastic people and it continued for over 19 years. Now the '
                              'company reached over 200 colleagues and expanded in the following cities of Romania: '
                              'Bucharest, Iasi, Cluj-Napoca, Alba Iulia, Reghin and Sibiu.',
    'estimations-yes'       : 'We can\'t wait to get in touch with you and hear your ideas. Please contact us via '
                              'email at office@reea.net and one of our software architects will get in touch with you '
                              'for further details about an estimation for your project!',
    'estimations-no'        : 'Ok then. For any other information about what we do and about how can we help you, '
                              'please contact us via email at office@reea.net. Have a wonderful day!',
    'interview'             : 'We appreciate passionate people and we can\'t wait to see your CV. Please send it to '
                              'office@reea.net and one of our colleagues will get in touch with you.',
    'portfolio'             : 'We took the ideas of the clients and transformed them into reality. From simple to '
                              'giant platforms, from mobile to creative games, we\'ve done them all. Here is a small '
                              'showcase of what we can do: <a href="https://www.reea.net/portfolio/">'
                              'https://www.reea.net/portfolio/</a>',
    'services'              : {
        'general'       : 'We offer a wide variety of services which include: Strategy & Branding, UI, UX, Web '
                          'Development, Video & Animation, Mobile Development, Copywriting & PR, Online Marketing, '
                          'AR & VR and many more. Which service are you interested in?',
        'target_entity' : 'We offer services in {0}. Would you like a time/cost estimation for your project?',
    },
    'technologies'          : {
        'general'       : 'I don\'t know anything about this. You should discuss with my technical colleagues about '
                          'the technology stack via email at <a href="mailto:office@reea.net">office@reea.net</a>',
        'target_entity' : 'We have experience with {0} and we\'ve developed many projects using this technology. '
                          'You can ask further details about this via email at '
                          '<a href="mailto:office@reea.net">office@reea.net</a>',
    },
    'contact'               : {
        'general'       : 'You can get it touch with us via email at <a href="mailto:office@reea.net">office@reea.net'
                          '</a>, via phone at <a href="tel:+40 365 410 942">+40 365 410 942</a> / <a href="tel:+40'
                          ' 745 992 463"> +40 745 992 463</a> or write us <a href="https://www.reea.net/contact/">'
                          'here</a>. We will make sure all of your questions will be answered. Thank you!',
        'phone'         : [
                          'You can call us via phone at <a href="tel:+40 365 410 942">+40 365 410 942</a> / '
                          '<a href="tel:+40 745 992 463"> +40 745 992 463</a>.', 'The phone numbers for contact are '
                          '<a href="tel:+40 365 410 942">+40 365 410 942</a> and <a href="tel:+40 745 992 463"> '
                          '+40 745 992 463</a>.', 'Please call us on these numbers <a href="tel:+40 365 410 942">'
                          '+40 365 410 942</a> / <a href="tel:+40 745 992 463"> +40 745 992 463</a>.'
                          ],
        'email'         : [
                          'You can contact us via email at <a href="mailto:office@reea.net">office@reea.net'
                          '</a>.',
                          'The email address where you can contact us is <a href="mailto:office@reea.net">'
                          'office@reea.net</a>.', 'You can get it touch with us by sending an email at '
                          '<a href="mailto:office@reea.net">office@reea.net</a>.'
                          ]
    }
}
