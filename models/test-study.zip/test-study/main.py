from flask import Flask, request, jsonify, render_template, send_from_directory
import json
import os
import dialogflow
import database
from actions import call_action
from google.oauth2 import service_account
from flask_cors import CORS, cross_origin

app = Flask(__name__)
CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'


def exclude_from_token_verification(func):
    func._exclude_from_token_verification = True
    return func


@app.route('/js/chat')
@exclude_from_token_verification
def send_js():
    return send_from_directory('static', 'js/chat.js')


@app.route('/js/iframe-chat')
@exclude_from_token_verification
def send_iframe_chat():
    return send_from_directory('static', 'js/iframeDimensionComputationsServer.js')


@app.route('/css/chat')
@exclude_from_token_verification
def send_css():
    return send_from_directory('static', 'css/chat.css')


@app.route('/responsive-css/chat')
@exclude_from_token_verification
def send_responsive_css():
    return send_from_directory('static', 'css/responsive.css')


@app.route('/fonts/<name>', methods=['GET'])
@exclude_from_token_verification
def send_font(name):
    return send_from_directory('static', 'fonts/' + name)


@app.route('/bot/chat-markup/<token>', methods=['GET'])
@exclude_from_token_verification
def bot_chat_markup(token):
    domain = os.environ.get('API_DOMAIN')
    return render_template('chat.html', api_domain=domain, token=token)


@app.route('/serve/<file>')
@exclude_from_token_verification
def send_static_image(file):
    return send_from_directory('static', 'images/' + file)


@app.before_request
def verify_token():
    run_token_verification = True

    if request.endpoint in app.view_functions:
        view_func = app.view_functions[request.endpoint]
        run_token_verification = not hasattr(
            view_func, '_exclude_from_token_verification')

    if run_token_verification and request.method != 'OPTIONS':
        domain = request.environ.get('HTTP_REFERER', os.environ.get('API_DOMAIN'))
        token = request.headers.get('Authorization')

        if token is None:
            response_text = {
                "message": "No token in Authorization header"}
            return jsonify(response_text), 401

        global client_details
        client_details, result = database.get_client_info(token, domain)

        if result is False:
            response_text = {
                "message": "Unauthorized to perform this request"}
            return jsonify(response_text), 401


@app.route('/get_template', methods=['GET'])
def get_template():
    return render_template('chat.html')


@app.route('/fulfillment', methods=['POST'])
@exclude_from_token_verification
def fulfillment():
    data = request.get_json(silent=True)

    # we determined the intent and we`ll call the appropriate function for fulfillment
    return call_action(data)


@app.route('/verify-token', methods=['OPTIONS', 'GET'])
@cross_origin()
def verify_access():
    # client_details - which are taken from the middleware
    return jsonify(client_details['domain']), 200


@app.route('/send_message', methods=['POST'])
def send_message():
    message = request.form['message']
    dialogflow_project_id = client_details['dialogflow_project_id']
    fulfillment_text = detect_intent_texts(dialogflow_project_id, "unique", message, 'en')
    response_text = {"message":  fulfillment_text}
    return jsonify(response_text)


def detect_intent_texts(project_id, session_id, text, language_code):
    result_credentials = json.loads(client_details['credentials'])
    credentials = service_account.Credentials.from_service_account_info(
        result_credentials)
    session_client = dialogflow.SessionsClient(credentials=credentials)
    session = session_client.session_path(project_id, session_id)

    if text:
        text_input = dialogflow.types.TextInput(text=text, language_code=language_code)
        query_input = dialogflow.types.QueryInput(text=text_input)
        response = session_client.detect_intent(session=session, query_input=query_input)
        return response.query_result.fulfillment_text


# run Flask app
if __name__ == "__main__":
    app.run()
