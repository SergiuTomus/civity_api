import pymysql
import os


def connect():
    host = os.environ.get('DBHOST')
    user = os.environ.get('DBUSER')
    password = os.environ.get('DBPASSWORD')
    db = os.environ.get('DBDATABASE')
    return pymysql.connect(
        host=host, user=user, password=password, db=db, cursorclass=pymysql.cursors.DictCursor)


def get_client_info(token, domain):
    conn = connect()
    cur = conn.cursor()
    try:
        cur.execute(
            "SELECT * FROM client WHERE token = %s", [token])
        client_details = cur.fetchone()
        return client_details, _check_client_token_match(token, domain, client_details)
    except Exception as e:
        print({'error': str(e)})
        return None
    finally:
        cur.close()
        conn.close()


def _check_client_token_match(token, domain, client_details):
    # This logic applies for two different cases:
    # 1 - when an initial call is made from the CLIENT's server (with his domain: eg: dedeman.ro)
    # 2 - when you send a message from the client's side, another internal call is triggered from within the server
    # itself.  This is because when "/send-message" API call is triggered, it will be launched from a js script that is
    # hosted on our server and the client is accessing it through an API call (See "/js/chat" ENDPOINT on client side)
    if token == client_details['token'] and (client_details['domain'] in domain or os.environ.get('API_DOMAIN') in domain):
        return True
    return False
