import {GET_RESTAURANT_SUCCEEDED} from '../actions/types';

const initialState = {
    restaurant: {},
    categories: [],
    products: []
}

const restaurantReducer = (state = initialState, action) => {   
    switch (action.type) {
        case GET_RESTAURANT_SUCCEEDED:
            return {
                ...state,
                restaurant: action.payload.restaurant,
                categories: action.payload.categories,
                products: action.payload.products,
            }
        default:
            return state;
    }

    
}

export default restaurantReducer;