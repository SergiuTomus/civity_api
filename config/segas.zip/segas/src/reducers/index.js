import { combineReducers } from 'redux';
import { connectRouter } from 'connected-react-router';
import { reducer as FormReducer } from 'redux-form';
import localeReducer from './locale.reducer';
import restaurantReducer from './restaurant.reducer';
import loadingReducer from './loading.reducer';
import generalReducer from './general.reducers';
import cityReducer from './city.reducer';

export default (history) => combineReducers({
    router: connectRouter(history),
    form: FormReducer,
    loadingReducer: loadingReducer,
    generalReducer: generalReducer,
    localeReducer: localeReducer,
    restaurantReducer: restaurantReducer,
    cityReducer: cityReducer
})