import { SHOW_GENERAL_ERROR, HIDE_GENERAL_ERROR, REQUEST_SUCCEEDED_MESSAGE, REQUEST_FAILED_MESSAGE } from '../actions/types';

export default function (state = {}, action) {

    switch (action.type) {

        case REQUEST_SUCCEEDED_MESSAGE:
            
            console.log(action);

            return Object.assign({}, state, {
                [action.payload.actionType] : {
                    [REQUEST_SUCCEEDED_MESSAGE] : action.payload.message,
                    [REQUEST_FAILED_MESSAGE] : null
                }
            });
        
        case REQUEST_FAILED_MESSAGE:
    
            return Object.assign({}, state, {
                [action.payload.actionType] : {
                    [REQUEST_FAILED_MESSAGE] : action.payload.message,
                    [REQUEST_SUCCEEDED_MESSAGE] : null
                }
            });

        

        case SHOW_GENERAL_ERROR:
            return {
                ...state,
                errorMessage: action.payload
            }

        case HIDE_GENERAL_ERROR:
            return {
                ...state,
                errorMessage: action.payload
            }
        default:
            return state;
    }
}
