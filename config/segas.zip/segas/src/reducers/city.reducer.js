import {GET_CITY_SUCCEEDED} from '../actions/types';

const initialState = {
    restaurants: null,
    stores_types: [],
    kitchen_types: []
}

const cityReducer = (state = initialState, action) => {   
    switch (action.type) {
        case GET_CITY_SUCCEEDED:
            // console.log("payload", action.payload);
            return {
                ...state,
                restaurants: action.payload.restaurants,
                stores_types: action.payload.stores_types,
                kitchen_types: action.payload.kitchen_types
            }
        default:
            return state;
    }

    
}

export default cityReducer;