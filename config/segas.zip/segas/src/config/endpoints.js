//############################################ USER-ENDPOINTS ###############################
export const USER_REGISTER_ENDPOINT = '/api_v2/v2/customers/register';
export const USER_FORGOT_PASSWORD_ENDPOINT = '/api_v2/v2/customers/forgot_password';
export const USER_RESETPASSWORD_ENDPOINT = '/api_v2/v2/customers/reset-password';


//############################################ RESTAURANTS-ENDPOINTS ###############################
// get all data for a restaurant
export const GET_RESTAURANT_ENDPOINT = '/api_v3/v3/Restaurants/store_data';
// get all restaurants in a city
export const GET_CITY_ENDPOINT = '/api_v3/v3/Restaurants/city_stores_data';
