import axios from '../config/axios';
import { call } from 'redux-saga/effects';

import {USER_REGISTER_ENDPOINT, USER_FORGOT_PASSWORD_ENDPOINT, USER_RESETPASSWORD_ENDPOINT} from '../config/endpoints';



export function* register(payload, lang = ""){

    return yield call(axios.post, USER_REGISTER_ENDPOINT + (lang ? "/lang/"+lang : ""), payload);
}

export function* forgotPassword(payload, lang = ""){

    return yield call(axios.post, USER_FORGOT_PASSWORD_ENDPOINT + (lang ? "/lang/"+lang : ""), payload);
}


export function* resetPassword(payload, lang =""){
    
    return yield call(axios.post, USER_RESETPASSWORD_ENDPOINT + (lang ? "/lang/"+lang : ""), payload);
}

