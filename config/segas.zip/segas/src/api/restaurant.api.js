import axios from '../config/axios';
import { call } from 'redux-saga/effects';
import {GET_RESTAURANT_ENDPOINT} from '../config/endpoints';

export function* getRestaurant(payload){

    return yield call(axios.post, GET_RESTAURANT_ENDPOINT, payload);

}