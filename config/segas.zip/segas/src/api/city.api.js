import axios from '../config/axios';
import { call } from 'redux-saga/effects';
import {GET_CITY_ENDPOINT} from '../config/endpoints';

export function* getCity(payload){

    return yield call(axios.post, GET_CITY_ENDPOINT, payload);

}