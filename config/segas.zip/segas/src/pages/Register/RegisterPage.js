// @flow

import React, { Component} from 'react';
import RegisterForm from './RegisterForm';
import Spinner from '../../components/spinner/spinner.component';
import { connect } from 'react-redux';
import {requestRegisterAction} from '../../actions/user.actions';
import { REQUEST_REGISTER } from '../../actions/types';
import {mapStateToPropApiComponent } from '../../helpers/general.helper';


type propsType = {
    loading: boolean,
    success?: string,
    error?: string,
    requestRegisterAction: requestRegisterAction,
    lang?: string,
}


class RegisterPage extends Component<propsType, {}> {
    
    handleSubmit(values){
        this.props.requestRegisterAction(values, this.props.lang);
    }
    
    render(){
        return (
            <div>
                {this.props.loading !== 0 ? <Spinner /> : ''}
                {this.props.success}
                {this.props.error}
                <RegisterForm onSubmit={this.handleSubmit.bind(this)} />
            </div>
        )
    }
}

const mapDispatchToProps = {
    requestRegisterAction
}

export default connect(mapStateToPropApiComponent(REQUEST_REGISTER), mapDispatchToProps)(RegisterPage)