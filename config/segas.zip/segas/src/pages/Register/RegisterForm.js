import React from 'react';
import {Field, reduxForm} from 'redux-form';
import {FormattedMessage} from 'react-intl';
import {withRouter} from 'react-router';
import validate from './RegisterFormValidate';


const renderField = ({ input, label, type, meta: { touched, error, warning } }) => (
    <div>
      <label className="control-label">{label}</label>
      <div>
        <input {...input} placeholder={label} type={type} className="form-control" />
        {touched && ((error && <span className="text-danger">{error}</span>) || (warning && <span>{warning}</span>))}
      </div>
    </div>
  )


let RegisterForm = props => {
    const {handleSubmit} = props
    return (
        <form onSubmit={handleSubmit}>

            <div>
                <label><FormattedMessage id="RegisterForm.text.name" defaultMessage="Name"></FormattedMessage></label>
                <Field name="name" component={renderField} type="text" />
            </div>

            <div>
                <label><FormattedMessage id="RegisterForm.text.email" defaultMessage="Email"></FormattedMessage></label>
                <Field name="email" component={renderField} type="email" />
            </div>

            <div>
                <label><FormattedMessage id="RegisterForm.text.password" defaultMessage="Password"></FormattedMessage></label>
                <Field name="password" component={renderField} type="password" />
            </div>

            <div>
                <label><FormattedMessage id="RegisterForm.text.password_confirmation" defaultMessage="Password confirmation"></FormattedMessage></label>
                <Field name="password_confirmation" component={renderField} type="password" />
            </div>

            <div>
                <button type="submit"> <FormattedMessage id="RegisterForm.text.submit_button" defaultMessage="Submit"></FormattedMessage></button>
            </div>
           
        </form>
    )
}

RegisterForm = reduxForm({
    form: 'register',
    validate
})(RegisterForm)

export default withRouter(RegisterForm);