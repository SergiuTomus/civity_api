import React from 'react';
import {FormattedMessage} from 'react-intl';

const validate = values => {
    const errors = {};

    if(!values.email){
        errors.email = <FormattedMessage id="RegisterFrom.constraints.required" defaultMessage="This field is required"></FormattedMessage>
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
        errors.email = <FormattedMessage id="RegisterFrom.constraints.email_invalid" defaultMessage="The email address is not valid"></FormattedMessage>
    }

    if(!values.password){
        errors.password = <FormattedMessage id="RegisterFrom.constraints.required" defaultMessage="This field is required"></FormattedMessage>
    }else if(!/^.{8,}$/.test(values.password)){
        errors.password = <FormattedMessage id="RegisterFrom.constraints.password_invalid" defaultMessage="The password needs at to be at least 8 characters long"></FormattedMessage>
    }

    if(!values.password_confirmation){
        errors.password_confirmation = <FormattedMessage id="RegisterFrom.constraints.required" defaultMessage="This field is required"></FormattedMessage>
    }else if(values.password_confirmation !== values.password){
        errors.password_confirmation = <FormattedMessage id="RegisterFrom.constraints.password_confirmation_not_matching" defaultMessage="The confirmation password needs to be the same as the password"></FormattedMessage>
    }

    if(!values.name){
        errors.name = <FormattedMessage id="RegisterFrom.constraints.required" defaultMessage="This field is required"></FormattedMessage>
    }

    return errors;
}

export default validate;