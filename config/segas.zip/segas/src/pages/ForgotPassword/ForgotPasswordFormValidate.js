import React from 'react';
import Validators, { email, required, validateForm } from "redux-form-validators";
import { FormattedMessage } from "react-intl";

Validators.formatMessage = function(msg) {
  return <FormattedMessage {...msg.props || msg} />
};

export const validate = validateForm({
  email: [
    required({
      msg: <FormattedMessage id="ForgotPasswordForm.constraints.email_required" defaultMessage="Email is required" />
    }),
    email({
      msg: <FormattedMessage id="ForgotPasswordForm.constraints.email_invalid" defaultMessage="Email is invalid"/>
    })
  ],
 
});
