import React from 'react';
import {Field, reduxForm} from 'redux-form';
import {FormattedMessage} from 'react-intl';
import {validate} from './ForgotPasswordFormValidate';


const renderField = ({ input, label, type, meta: { touched, error, warning } }) => (
    <div>
      <label className="control-label">{label}</label>
      <div>
        <input {...input} placeholder={label} type={type} className="form-control" />
        {touched && ((error && <span className="text-danger">{error}</span>) || (warning && <span>{warning}</span>))}
      </div>
    </div>
  )


let ForgotPasswordForm = props => {
    const {handleSubmit} = props
    return (
        <form onSubmit={handleSubmit}>

    
            <div>
                <label><FormattedMessage id="ForgotPasswordForm.text.email" defaultMessage="Email"></FormattedMessage></label>
                <Field name="email" component={renderField} type="email" />
            </div>

    
            <div>
                <button type="submit"> <FormattedMessage id="ForgotPasswordForm.text.submit_button" defaultMessage="Submit"></FormattedMessage></button>
            </div>
        
        </form>
    )
}

ForgotPasswordForm = reduxForm({
    form: 'forgot-password',
    validate
})(ForgotPasswordForm)

export default ForgotPasswordForm;
