// @flow

import React, { Component} from 'react';
import ForgotPasswordForm from './ForgotPasswordForm';
import Spinner from '../../components/spinner/spinner.component';
import { connect } from 'react-redux';
import {requestForgotPasswordAction} from '../../actions/user.actions';
import {mapStateToPropApiComponent } from '../../helpers/general.helper';
import {REQUEST_FORGOT_PASSWORD} from '../../actions/types';

type propsType = {
    loading: boolean,
    success?: string,
    error?: string,
    requestForgotPasswordAction: requestForgotPasswordAction,
    lang?: string
}


class ForgotPasswordPage extends Component<propsType, {}> {

    handleSubmit(values){
        this.props.requestForgotPasswordAction(values, this.props.lang);
    }
    
    render(){
        return (
            <div>
                {this.props.loading !== 0 ? <Spinner /> : ''}
                {this.props.success}
                {this.props.error}
                <ForgotPasswordForm onSubmit={this.handleSubmit.bind(this)} />
            </div>
        )
    }
}

const mapDispatchToProps = {
    requestForgotPasswordAction
}

export default connect(mapStateToPropApiComponent(REQUEST_FORGOT_PASSWORD), mapDispatchToProps)(ForgotPasswordPage)
