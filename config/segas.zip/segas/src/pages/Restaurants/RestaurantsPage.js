import React, { Component } from 'react';
import { connect } from 'react-redux';
import { getCityData } from '../../actions/city.actions';
import RestaurantItem from '../../components/restaurant/restaurantItem.component';
import Spinner from '../../components/spinner/spinner.component';

class RestaurantsPage extends Component {
  componentDidMount() {
    let payload: Object = {
      cityId: "209"
    }

    this.props.getCityData(payload);

  }

  render() {
      const { restaurants } = this.props;
      console.log("restaurants", restaurants);

      let restaurants_list;
      if (restaurants === null) { // todo loading
        restaurants_list = <Spinner loading={1}/>; // todo fix spinner
      } else {
        restaurants_list = restaurants.map(restaurant => <RestaurantItem key={restaurant.id} restaurant={restaurant} />);
      }

      return (
        <div>
            <div style={{height: 160, backgroundColor: "#FF0000"}}>
              <p>Header placeholder</p>
            </div>
            <div  className="container bg-info">
              {/* <RestaurantItem />
              <RestaurantItem />
              <RestaurantItem />
              <RestaurantItem />
              <RestaurantItem />
              <RestaurantItem />
              <RestaurantItem />
              <RestaurantItem />
              <RestaurantItem />
              <RestaurantItem /> */}

              {restaurants_list}
            </div>
        </div>

      );
  }

}

const mapStateToProps = state => ({
  restaurants: state.cityReducer.restaurants
});
export default connect(mapStateToProps, { getCityData })(RestaurantsPage);