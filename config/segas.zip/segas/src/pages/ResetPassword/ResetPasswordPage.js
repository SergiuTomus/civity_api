// @flow

import React, { Component} from 'react';
import ResetPasswordForm from './ResetPasswordForm';
import Spinner from '../../components/spinner/spinner.component';
import { connect } from 'react-redux';
import {requestResetPasswordAction} from '../../actions/user.actions';
import {mapStateToPropApiComponent } from '../../helpers/general.helper';
import {withRouter} from 'react-router';


type propsType = {
    loading: boolean,
    success?: string,
    error?: string,
    requestResetPasswordAction: requestResetPasswordAction,
    match: {
        params: {
            token: string
        }
    },
    lang?: string,
}


class ResetPasswordPage extends Component<propsType, {}> {
    
    handleSubmit(values){
        this.props.requestResetPasswordAction(values, this.props.lang);
    }
    
    render(){
        let initialValues = {
            token: this.props.match.params.token
        }
        return (
            <div>
                {this.props.loading !== 0 ? <Spinner /> : ''}
                {this.props.success}
                {this.props.error}
                <ResetPasswordForm onSubmit={this.handleSubmit.bind(this)} initialValues={initialValues} />
            </div>
        )
    }
}

const mapDispatchToProps = {
    requestResetPasswordAction
}

// $FlowFixMe
export default withRouter(connect(mapStateToPropApiComponent, mapDispatchToProps)(ResetPasswordPage))