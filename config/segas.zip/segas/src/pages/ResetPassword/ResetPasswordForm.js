import React from 'react';
import {Field, reduxForm} from 'redux-form';
import {FormattedMessage} from 'react-intl';
import validate from './ResetPasswordFormValidate';


const renderField = ({ input, label, type, meta: { touched, error, warning } }) => (
    <div>
      <label className="control-label">{label}</label>
      <div>
        <input {...input} placeholder={label} type={type} className="form-control" />
        {touched && ((error && <span className="text-danger">{error}</span>) || (warning && <span>{warning}</span>))}
      </div>
    </div>
  )


let ResetPasswordForm = props => {

    const {handleSubmit} = props
    return (
        <form onSubmit={handleSubmit}>

            <div>
                <label><FormattedMessage id="ResetPasswordForm.text.password" defaultMessage="Password"></FormattedMessage></label>
                <Field name="password" component={renderField} type="password" />
            </div>

            <div>
                <label><FormattedMessage id="ResetPasswordForm.text.password_confirmation" defaultMessage="Password confirmation"></FormattedMessage></label>
                <Field name="password_confirmation" component={renderField} type="password" />
            </div>

            <Field name="token" component="input" type="hidden"/>

            <div>
                <button type="submit"> <FormattedMessage id="ResetPasswordForm.text.submit_button" defaultMessage="Submit"></FormattedMessage></button>
            </div>
           
        </form>
    )
}

ResetPasswordForm = reduxForm({
    form: 'reset-password',
    validate
})(ResetPasswordForm)

export default ResetPasswordForm;