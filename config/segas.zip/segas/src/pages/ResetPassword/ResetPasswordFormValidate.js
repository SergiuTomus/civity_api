import React from 'react';
import {FormattedMessage} from 'react-intl';

const validate = values => {
    const errors = {};

    if(!values.password){
        errors.password = <FormattedMessage id="ResetPasswordForm.constraints.required" defaultMessage="This field is required"></FormattedMessage>
    }else if(!/^.{8,}$/.test(values.password)){
        errors.password = <FormattedMessage id="ResetPasswordForm.constraints.password_invalid" defaultMessage="The password needs at to be at least 8 characters long"></FormattedMessage>
    }

    if(!values.password_confirmation){
        errors.password_confirmation = <FormattedMessage id="ResetPasswordForm.constraints.required" defaultMessage="This field is required"></FormattedMessage>
    }else if(values.password_confirmation !== values.password){
        errors.password_confirmation = <FormattedMessage id="ResetPasswordForm.constraints.password_confirmation_invalid" defaultMessage="The confirmation password does not match the password entered"></FormattedMessage>
    }

    return errors;
}

export default validate;