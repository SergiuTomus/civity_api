// @flow
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { FormattedMessage } from 'react-intl';
import { getRestaurant } from '../../actions/restaurant.actions';


type HomeProps = {
  getRestaurant: Function,
};

type HomeState = {
  state: string,
};

class HomePage extends Component<HomeProps, HomeState>{

  componentDidMount() {
    let payload: Object = {
      storeId: "254"
    }

    this.props.getRestaurant(payload);

  }

  render() {
      return (
        <div>
          <FormattedMessage id="homepage" defaultMessage="homepage message"/>
        </div>
      );
  }

}

const mapStateToProps = state => ({
    restaurant: state.restaurantReducer.restaurant
});
export default connect(mapStateToProps, { getRestaurant })(HomePage);