export type RegisterPayload = {
    name: string,
    email: string,
    password: string,
    password_confirmation: string
}


export type ForgotPasswordPayload = {
    email: string
}

export type ResetPasswordPayload = {
    token: string,
    password: string,
    password_confirmation: string
}

export type Action = {
    type: string,
    payload: UserPayload | FBUserPayload  | RegisterPayload | ForgotPasswordPayload,
    lang?: string
    // payload: UserPayload | FBUserPayload  | RegisterPayload | ResetPasswordPayload

};
  
export type Saga<T> = Generator<Effect, T, any>;