import {
    REQUEST_REGISTER,
    REQUEST_FORGOT_PASSWORD,
    REQUEST_RESETPASSWORD
} from './types';

import {
    RegisterPayload,
    ForgotPasswordPayload,
    ResetPasswordPayload,
    Action
} from '../types/user.types';


export const requestRegisterAction = (payload : RegisterPayload, lang? : String) : Action => ({
    type: REQUEST_REGISTER,
    payload: payload,
    lang: lang
});

export const requestForgotPasswordAction = (payload : ForgotPasswordPayload, lang?: String) : Action => ({
    type: REQUEST_FORGOT_PASSWORD,
    payload: payload,
    lang: lang
});


export const requestResetPasswordAction = (payload: ResetPasswordPayload, lang?: string) => ({
    type: REQUEST_RESETPASSWORD,
    payload: payload,
    lang: lang
})

