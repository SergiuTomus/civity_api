import { GET_CITY_DATA, GET_CITY_SUCCEEDED } from './types';


export const getCityData = (payload) => {
      return {
          type : GET_CITY_DATA,
          payload
      }
}

export const getCitySucceded = (payload) => {
      return {
          type : GET_CITY_SUCCEEDED,
          payload
      }
}