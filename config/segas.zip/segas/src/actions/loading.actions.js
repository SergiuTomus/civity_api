import { INCREMENT_PENDING_REQUESTS, DECREMENT_PENDING_REQUESTS } from "./types";

export const showSpinner = (payload) => ({
    type: INCREMENT_PENDING_REQUESTS,
    payload
})

export const hideSpinner = (payload) => ({
    type: DECREMENT_PENDING_REQUESTS,
    payload
})
