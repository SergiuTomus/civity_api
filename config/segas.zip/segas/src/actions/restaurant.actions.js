import { GET_RESTAURANT, GET_RESTAURANT_SUCCEEDED } from './types';


export const getRestaurant = (payload) => {
      return {
          type : GET_RESTAURANT,
          payload
      }
}

export const getRestaurantSucceded = (payload) => {
      return {
          type : GET_RESTAURANT_SUCCEEDED,
          payload
      }
}
