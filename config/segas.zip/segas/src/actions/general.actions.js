// @flow

import {SHOW_GENERAL_ERROR, REQUEST_SUCCEEDED, REQUEST_FAILED, HIDE_GENERAL_ERROR, REQUEST_FAILED_MESSAGE, REQUEST_SUCCEEDED_MESSAGE} from './types';

export const showGeneralError = (payload : string) => ({
    type : SHOW_GENERAL_ERROR,
    payload
})

export const hideGeneralError = (payload?: string) => ({
    type : HIDE_GENERAL_ERROR,
    payload
})

export const requestSucceeded = (actionType : string, payload : {}) => ({
    type: REQUEST_SUCCEEDED,
    payload: { "type": actionType, "response" : payload}
});

export const requestFailed = (actionType : string , payload : {}) => ({
    type: REQUEST_FAILED,
    payload: { "type": actionType, "response" : payload}
});

export const requestFailedMessage = (actionType: string, message: string) => ({
    type: REQUEST_FAILED_MESSAGE,
    payload: {
        actionType: actionType,
        message: message
    }
})

export const requestSucceededMessage = (actionType : string, message : string) => ({
    type: REQUEST_SUCCEEDED_MESSAGE,
    payload: {
        actionType: actionType,
        message: message
    }
});
