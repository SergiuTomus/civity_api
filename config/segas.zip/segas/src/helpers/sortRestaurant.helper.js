
// all the data for one restaurant
export function getRestaurantData(restaurant) {
    var restaurantData = [];

    restaurantData.push({
        id: parseInt(restaurant.id),
        name: restaurant.name,
        address: restaurant.address,
        phone: restaurant.phone,
        email: restaurant.email,
        site: restaurant.site,
        logo: restaurant.logo,
        // restaurant_main_type_ro: restaurant.store_type[Object.keys(restaurant.store_type)[0]].title,
        latitude: parseFloat(restaurant.latitude),
        longitude: parseFloat(restaurant.longitude),
        delivery_latitude: restaurant.delivery_latitude,
        delivery_longitude: restaurant.delivery_longitude,
        delivery_radius: restaurant.delivery_radius,
        delivery_minutes: parseInt(restaurant.delivery_minutes),
        min_cart: parseInt(restaurant.min_cart),
        maintenance_mode: parseInt(restaurant.maintenance_mode),
        maintenance_text: restaurant.maintenance_text,
        listing_order: parseInt(restaurant.listing_order),
        opening_hours: restaurant.opening_hours,
        facebook_page_id: parseInt(restaurant.facebook_page_id),
        logo_small: restaurant.logo_small,
        logo_share: restaurant.logo_share,
        opened: parseInt(restaurant.opened),
        hours: restaurant.hours,
        rating: restaurant.rating,
        full_link: restaurant.full_link,
        country_name: restaurant.country_name,
        currency: restaurant.currency,
        payment_methods: paymentMethodsGet(restaurant.payment_methods)
    });
    return restaurantData;
};

function paymentMethodsGet(item) {
    const keyArray = Object.keys(item)
    var text = ""
    if (keyArray.indexOf("cash") > -1) {
        text = "Cash&"
    }
    if (keyArray.indexOf("online_card") > -1) {
        text = text + "Card&"
    }
    if (keyArray.indexOf("credit_card_pos") > -1) {
        text = text + "POS&"
    }
    text = text.substring(0, text.length - 1)
    return text
};



// all product types for one restaurant
export function getRestaurantCategories(restaurant) {   // like getRestaurantProductTypes || getProductsCategoryTypes
  let categories = [];
  Object.keys(restaurant.products.product_types).forEach((productType, item) => {
      if (restaurant.products.product_types[productType].name) {
          categories.push({
              id: parseInt(restaurant.products.product_types[productType].id),
              name_ro: restaurant.products.product_types[productType].name.ro.value,
              name_en: restaurant.products.product_types[productType].name.en.value,
              number_of_products: parseInt(restaurant.products.product_types[productType].count),
              product_type_photo: restaurant.products.product_types[productType].product_type_photo,
              product_type_photo_medium: restaurant.products.product_types[productType].product_type_photo_medium,
              product_type_photo_original: restaurant.products.product_types[productType].product_type_photo_original
          });
      }
  });
  return categories;
};




// all the products for one category in a restaurant
export function getCategoryProducts(restaurant){  // like getProductWithProductType
  let products = [];
  let category_id = [];
  let restaurant_id = parseInt(restaurant.id);

  // mapping product types
  Object.keys(restaurant.products.product_types).forEach((productType, item) => {
    // getting the category id for the corresponding product
    category_id = parseInt(restaurant.products.product_types[productType].id);
    // mapping products for one category
    if (restaurant.products.product_types[productType].name) {

       Object.keys(restaurant.products.product_types[productType].configurable).forEach((product, i) => {
          // array for product weights ids
          let ids_product_simple = [];
          for (var i = 0; i < restaurant.products.product_types[productType].configurable[product].simple.length; i++) {
              ids_product_simple.push(parseInt(restaurant.products.product_types[productType].configurable[product].simple[i].id));
          }

          let ids_product_extra = [];
          for (var i = 0; i < restaurant.products.product_types[productType].configurable[product].extras.length; i++) {
              ids_product_extra.push(parseInt(restaurant.products.product_types[productType].configurable[product].extras[i].id));
          }

          var ids_product_categs = [];
          Object.keys(restaurant.products.product_types[productType].configurable[product].product_configurable_type).map((categ, item) => {
              ids_product_categs.push(parseInt(restaurant.products.product_types[productType].configurable[product].product_configurable_type[categ].id));
          });

          let has_special_price = 0;
          Object.keys(restaurant.products.product_types[productType].configurable[product].simple).map((categ, item) => {
              has_special_price = parseInt(restaurant.products.product_types[productType].configurable[product].simple[categ].promotion_status)
          });


          products.push({
                    id: parseInt(restaurant.products.product_types[productType].configurable[product].id),
                    name_ro: restaurant.products.product_types[productType].configurable[product].name.ro.value,
                    name_en: restaurant.products.product_types[productType].configurable[product].name.en.value,
                    description_ro: restaurant.products.product_types[productType].configurable[product].description.ro.value,
                    description_en: restaurant.products.product_types[productType].configurable[product].description.en.value,
                    photo: restaurant.products.product_types[productType].configurable[product].photo,
                    photo_medium: restaurant.products.product_types[productType].configurable[product].photo_medium,
                    photo_original: restaurant.products.product_types[productType].configurable[product].photo_original,
                    rating: restaurant.products.product_types[productType].configurable[product].rating,
                    rating_count: restaurant.products.product_types[productType].configurable[product].rating_nr,
                    tva: parseInt(restaurant.products.product_types[productType].configurable[product].tva),
                    discontabil: parseInt(restaurant.products.product_types[productType].configurable[product].discontabil),
                    has_allergens: parseInt(restaurant.products.product_types[productType].configurable[product].has_allergens),
                    // allergens_en: restaurant.products.product_types[productType].configurable[product].allergens && restaurant.products.product_types[productType].configurable[product].allergens.length > 0 ? restaurant.products.product_types[productType].configurable[product].allergens.en.value : null,
                    carbohydrates_ro: restaurant.products.product_types[productType].configurable[product].carbohydrates && restaurant.products.product_types[productType].configurable[product].carbohydrates.length > 0 ? restaurant.products.product_types[productType].configurable[product].carbohydrates.ro.value : null,
                    carbohydrates_en: restaurant.products.product_types[productType].configurable[product].carbohydrates && restaurant.products.product_types[productType].configurable[product].carbohydrates.length > 0 ? restaurant.products.product_types[productType].configurable[product].carbohydrates.en.value : null,
                    proteines_ro: restaurant.products.product_types[productType].configurable[product].proteines && restaurant.products.product_types[productType].configurable[product].proteines.length > 0 ? restaurant.products.product_types[productType].configurable[product].proteines.ro.value : null,
                    proteines_en: restaurant.products.product_types[productType].configurable[product].proteines && restaurant.products.product_types[productType].configurable[product].proteines.length > 0 ? restaurant.products.product_types[productType].configurable[product].proteines.en.value : null,
                    fats_ro: restaurant.products.product_types[productType].configurable[product].fats && restaurant.products.product_types[productType].configurable[product].fats.length > 0 ? restaurant.products.product_types[productType].configurable[product].fats.ro.value : null,
                    fats_en: restaurant.products.product_types[productType].configurable[product].fats && restaurant.products.product_types[productType].configurable[product].fats.length > 0 ? restaurant.products.product_types[productType].configurable[product].fats.en.value : null,
                    products_simple: ids_product_simple,
                    category_id: category_id,
                    restaurant_id: restaurant_id,
                    photo_restaurant: restaurant.logo_small,
                    extra_types: ids_product_extra,
                    categ_types: ids_product_categs,
                    has_special_price: has_special_price,
                                    
          })
       });
    } else {
      console.log("no product for this product type")
    }
  });
  return products;
};



// get one product with all the variations and extras
export function getProductWithVariations(restaurant){ // like getProductsSimpleWithProduct || getProductsExtraWithProduct

};

export function getPackages(restaurant){

};
