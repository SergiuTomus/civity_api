// search for duplicates and returns a new array containing only unique elements
export default function removeDuplicates(arr, key = 'id') {
  
   const map = new Map();
    arr.map(item => {
        if (!map.has(item[key])) {
            map.set(item[key], item);
        }
    });
    return [...map.values()];
};