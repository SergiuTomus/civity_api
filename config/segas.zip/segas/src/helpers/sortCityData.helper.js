import removeDuplicates from './removeDuplicates.helper';





// get the list of kitchen types
export function getStoreKitchens(restaurant) {
    let store_kitchens_types = [];

    Object.keys(restaurant.store_kitchen_type).forEach((kitchen, item) => {
        store_kitchens_types.push({ 
              id: restaurant.store_kitchen_type[kitchen].id,
              name_ro: restaurant.store_kitchen_type[kitchen].title.ro.value,
              name_en: restaurant.store_kitchen_type[kitchen].title.en.value,
              logo: restaurant.store_kitchen_type[kitchen].logo_url 
        });
    });
    return store_kitchens_types;

}

export function getStoresTypes(restaurant) {
    let store_types = [];
    // console.log("restaurant", restaurant);

    Object.keys(restaurant.store_type).forEach((store, item) => {
        store_types.push({ 
              id: restaurant.store_type[store].id,
              name_ro: restaurant.store_type[store].title.ro.value,
              name_en: restaurant.store_type[store].title.en.value,
              logo: restaurant.store_type[store].logo_url
        });
    });
    // console.log("store_types", store_types);
    return store_types;
}



export function sortData(city_data){
    let stores_data = {}
    let all_kitchen_types = [];
    let all_stores_types = [];

    city_data.map((store, index) => {
        all_kitchen_types.push(...getStoreKitchens(store));
        all_stores_types.push(...getStoresTypes(store));
    });
    // console.log("all_stores_types", all_stores_types);
    let kitchen_types = removeDuplicates(all_kitchen_types);
    let stores_types = removeDuplicates(all_stores_types);

    stores_data.kitchen_types = kitchen_types;
    stores_data.restaurants = city_data;
    stores_data.stores_types = stores_types;

    // console.log("stors_data: ", stores_data);
    return stores_data;

}