import { REQUEST_REGISTER, REQUEST_SUCCEEDED_MESSAGE, REQUEST_FAILED_MESSAGE } from '../actions/types';


export const mapStateToPropApiComponent = (requestType, extraMapping) => {
    
    let mapStateToProps = function(state){

        let success, error = null;
        
        if(state.generalReducer[requestType] && state.generalReducer[requestType][REQUEST_SUCCEEDED_MESSAGE]){
            success =  state.generalReducer[requestType][REQUEST_SUCCEEDED_MESSAGE];
        }
    
        if(state.generalReducer[requestType] && state.generalReducer[requestType][REQUEST_FAILED_MESSAGE]){
            error =  state.generalReducer[requestType][REQUEST_FAILED_MESSAGE];
        }

        
        let finalMapping = {
            loading: state.loadingReducer.pendingRequests,
            error,
            success,
            lang: state.localeReducer.lang
        }

        if(extraMapping){
            return {
                ...finalMapping,
                ...extraMapping(state)
            }
        }
    
        return  finalMapping
    }

    return mapStateToProps;
}