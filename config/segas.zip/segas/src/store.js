import { createStore, applyMiddleware } from 'redux';
import createSagaMiddleware from 'redux-saga';
import createRootReducer  from './reducers/index';
import { composeWithDevTools } from 'redux-devtools-extension';
import rootSaga from './sagas/root';
import { routerMiddleware } from 'connected-react-router';
import history from './history.js';

const initialState = {};
const sagaMiddleware = createSagaMiddleware();


const store = createStore(
    createRootReducer(history),
    initialState,
    composeWithDevTools(applyMiddleware(routerMiddleware(history), sagaMiddleware))
);
sagaMiddleware.run(rootSaga);

export default store;