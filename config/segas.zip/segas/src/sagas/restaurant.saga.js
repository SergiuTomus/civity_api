// @flow
import {call, put, takeLatest} from 'redux-saga/effects';
import { GET_RESTAURANT } from '../actions/types';
import { getRestaurant } from '../api/restaurant.api';
import { getRestaurantSucceded } from '../actions/restaurant.actions';
import { baseRequest } from './helper.saga.js';
import { getRestaurantData, getRestaurantCategories, getCategoryProducts } from '../helpers/sortRestaurant.helper';

type RestaurantPayload = {
    storeId: string
}

type Action = {
    type: string,
    payload: RestaurantPayload
};

function* getRestaurantSaga(action: Action){
    try{
        // get from localStorage
        let dataLocalStorage: ?string = localStorage.getItem('restaurant-data');
        let data: Object;

        if (dataLocalStorage === null) {
          // call to restaurant endpoint
          let response: Object = yield call(baseRequest, action, getRestaurant);

          if (response && response.data.success === true) {
              data = response.data.data;
              // set to localStorage
              localStorage.setItem('restaurant-data', JSON.stringify(data));
              let restaurant;
            }
        } else {
          let dataString: string = dataLocalStorage || "";
          data = JSON.parse(dataString);
        }

        // sort data
        let restaurant = yield call(getRestaurantData, data);
        let categories = yield call(getRestaurantCategories, data);
        let products = yield call(getCategoryProducts, data);

        let restaurant_data = {
          restaurant: restaurant[0],
          categories,
          products
        }
        yield put(getRestaurantSucceded(restaurant_data));
    } 
    catch(error){
        console.log(error);
    }
    
}


export default function* restaurantWatcher(): Generator<Function, void, void>{
    yield takeLatest(GET_RESTAURANT, getRestaurantSaga);
}