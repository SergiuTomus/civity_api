
import {call, put, takeLatest} from 'redux-saga/effects';
import { GET_CITY_DATA } from '../actions/types';
import { getCity } from '../api/city.api';
import { getCitySucceded } from '../actions/city.actions';
import { baseRequest } from './helper.saga.js';
import { sortData } from '../helpers/sortCityData.helper';
import test_restaurants from './test_restaurants.json';


function* getCitySaga(action){

    let city_data;
    try{
      // let response = yield call(baseRequest, action, getCity);
      let response = test_restaurants;

      if (response && response.data.success === true) {
        city_data = response.data.data;

        yield put(getCitySucceded(city_data));

        // sort data
        let sorted_data = yield call(sortData, city_data);

        yield put(getCitySucceded(sorted_data));
        
      }
    } 
    catch(error){
        console.log(error);
    }
    
}


export default function* cityWatcher() {
    yield takeLatest(GET_CITY_DATA, getCitySaga);
}