// @flow
import {call, takeLatest, put} from 'redux-saga/effects';
import { REQUEST_REGISTER, REQUEST_FORGOT_PASSWORD, REQUEST_RESETPASSWORD } from '../actions/types';
import { register, forgotPassword, resetPassword } from '../api/user.api';
import {baseRequest, isSuccess} from './helper.saga';
import { requestSucceededMessage } from '../actions/general.actions';
import {
    Action,
    Saga
} from '../types/user.types';

function* registerUserAction(action : Action){

    //Do something with response data that can't be done in a reducer
    let response = yield call(baseRequest, action, register);
    
    if(isSuccess(response)){
        yield put(requestSucceededMessage(action.type, response.data.message));
    }
}


function* forgotPasswordAction(action){
    let response = yield call(baseRequest, action, forgotPassword);
}

function* resetPasswordAction(action : Action){

    //Do something with response data that can't be done in a reducer
    let response = yield call(baseRequest, action, resetPassword);
    
    if(isSuccess(response)){
        yield put(requestSucceededMessage(action.type, response.data.message));
    }
}


export default function* userWatcher(): Saga{
    yield takeLatest(REQUEST_REGISTER, registerUserAction);
    yield takeLatest(REQUEST_FORGOT_PASSWORD, forgotPasswordAction)
    yield takeLatest(REQUEST_RESETPASSWORD, resetPasswordAction);
}