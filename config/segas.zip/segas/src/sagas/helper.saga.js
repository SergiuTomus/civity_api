import {call, put, delay} from 'redux-saga/effects';
import { hideGeneralError, showGeneralError, requestFailedMessage } from '../actions/general.actions';
import { showSpinner, hideSpinner } from '../actions/loading.actions';

export function isSuccess(response){
    return response.status === 200 && response.data.success;
};

export function* baseRequest(action, apiSaga){

    try {
        yield put(showSpinner(action.type));
        const response = yield call(apiSaga, action.payload, action.lang);
        yield put(hideSpinner(action.type));
        if(!isSuccess(response)){
            yield put(requestFailedMessage(action.type, response.data.message));
        }
        
        return response;

    } catch(error){
        yield put(hideSpinner(action.type));
        yield put(showGeneralError("An general error occurred"));
        yield delay(2000)
        yield put(hideGeneralError());

    }
    
};




