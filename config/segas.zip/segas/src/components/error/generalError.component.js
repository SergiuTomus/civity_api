// @flow
import React from 'react';

type Props = {
  error: string,
};

export const GeneralError = (props: Props) => {
    
    return <div className="general-error-container">
        <span>{props.error}</span>
    </div>
}
