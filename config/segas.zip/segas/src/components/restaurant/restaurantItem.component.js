import React from 'react';

const restaurantItem = (props) => {
  console.log("in restaurantItem props:", props);
  return (
    <div className="store-item">
      <div className="store-item-card">
          <div className="storeTitle">{"Casa Muresana"}</div>
          <div className="storeImg-card">
            <img className="img-fluid store-img" src={"https://d1pvbaglzn4ury.cloudfront.net/r/l/548f76f0-cad5-47f5-8def-af963b320270"} alt={"restaurant_image"}/>
          </div>
          <div className="container">
            <div className="strikeTo-card row">
                <div className="strikeTo-line">
                  <hr />
                </div>
                <div className="strikeTo-title">
                  FAST FOOD
                </div>
                <div className="strikeTo-line">
                  <hr />
                </div>
            </div>
            <div className="row">
                <div className="order-card">
                  Comanda
                </div>
                <div className="time-card">
                  Timp livrare
                </div>
            </div>
            <div className="row">
                <div className="price-card">
                  20 RON
                </div>
                <div className="min-card">
                  60 min
                </div>
            </div>
          </div>
      </div>
      
    </div>
  )
}

export default restaurantItem;
